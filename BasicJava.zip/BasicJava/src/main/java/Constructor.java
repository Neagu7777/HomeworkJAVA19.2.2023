public class Constructor {

    String name;
    String unit_of_measurement;

    int height;
    int width;
    int depth;


    public Constructor(String n, int h, int w, int d, String u) {
        name = n;
        height = h;
        width = w;
        depth = d;
        unit_of_measurement = u;


    }

    }
