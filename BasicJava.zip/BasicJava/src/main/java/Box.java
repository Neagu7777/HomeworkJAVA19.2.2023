public class Box {

    public static void main(String[] args) {

       // Constructor a1 = new Constructor();

       // a1.name = "box";
       // a1.unit_of_measurement = "CM";
       // a1.height = 150;


        // Constructor a2 = new Constructor();

        //a2.name = "box";
        //a2.unit_of_measurement = "CM";
       // a2.width = 50;



       //Constructor a3 = new Constructor();

        //a3.name = "box";
       // a3.unit_of_measurement = "CM";
       // a3.depth = 150;



       //System.out.println("box = " +  "have "  + "height "  + a1.height + a1.unit_of_measurement + ", " + "width "  + a2.width + a1.unit_of_measurement + ", " + "depth "  + a3.depth + a1.unit_of_measurement );
       // System.out.println("box = " + a1.height + "X" + a2.width + "X" + a3.depth  + " " + a1.unit_of_measurement);

       //System.out.println("box = " +  "have "  + "width "  + a2.width + a2.unit_of_measurement);





        Constructor a1 = new Constructor( "Box", 150, 50, 150, "cm");
        a1.height = 150;
        a1.width = 50;
        a1.depth = 150;

        System.out.println("box = " +  "have "  + "height "  + a1.height + a1.unit_of_measurement + ", " + "width "  + a1.width + a1.unit_of_measurement + ", " + "depth "  + a1.depth + a1.unit_of_measurement );


       // Constructor v4 = new Constructor4("Box volume", 1.125, "m3" );
      //  v4.name = "Box volume ";
      //  v4.volume = 1.125;
       // v4.unit_of_measurement = "m3";

       // System.out.println("Box volume =" + v4.volume + " m3");




    }
}